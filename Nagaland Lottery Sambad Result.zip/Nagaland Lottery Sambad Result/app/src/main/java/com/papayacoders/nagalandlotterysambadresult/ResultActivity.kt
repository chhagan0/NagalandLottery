package com.papayacoders.nagalandlotterysambadresult

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Log.d
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.core.content.ContextCompat
import com.google.android.ads.nativetemplates.NativeTemplateStyle
import com.google.android.ads.nativetemplates.TemplateView
import com.google.android.gms.ads.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.papayacoders.nagalandlotterysambadresult.ads.backintersitial
import com.papayacoders.nagalandlotterysambadresult.ads.intertitial
import com.papayacoders.nagalandlotterysambadresult.ads.mainapp
import com.papayacoders.nagalandlotterysambadresult.config.Speciallottery
import com.papayacoders.nagalandlotterysambadresult.databinding.ActivityResultBinding
import com.papayacoders.nagalandlotterysambadresult.result.EightPMActivity
import com.papayacoders.nagalandlotterysambadresult.result.OldResultActivity
import com.papayacoders.nagalandlotterysambadresult.result.OnePMActivity
import com.papayacoders.nagalandlotterysambadresult.result.SixPMActivity

class ResultActivity : mainapp() {
    lateinit var binding: ActivityResultBinding
    private lateinit var mediaPlayer: MediaPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MobileAds.initialize(this)
        getspeciallottery()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this, R.color.mustredyellow)
        }
        binding.speciallottery.setOnClickListener {
            val inte = Intent(
                this,
                com.papayacoders.nagalandlotterysambadresult.result.Speciallottery::class.java
            )
            intertitial.showAds(this, inte)
            mediaPlayer.pause()

        }
        binding.btnback.setOnClickListener {
            val inte = Intent(this, MainActivity::class.java)
            backintersitial.showAds(this, inte)
            mediaPlayer.pause()

        }
        binding.oldresult.setOnClickListener {
            val inte = Intent(this, OldResultActivity::class.java)
            intertitial.showAds(this, inte)
            mediaPlayer.pause()

        }
        binding.onepm.setOnClickListener {
            val inte = Intent(this, OnePMActivity::class.java)
            intertitial.showAds(this, inte)
            mediaPlayer.pause()

        }
        binding.sixpm.setOnClickListener {
            val inte = Intent(this, SixPMActivity::class.java)
            intertitial.showAds(this, inte)
        }
        binding.eightpm.setOnClickListener {
            val inte = Intent(this, EightPMActivity::class.java)
            intertitial.showAds(this, inte)
            mediaPlayer.pause()

        }
        nativeads()
        mediaPlayer = MediaPlayer.create(this, R.raw.music)
        binding.play.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                binding.playicon.setImageResource(R.drawable.baseline_play_arrow_24)
            } else {
                mediaPlayer.start()
                binding.playicon.setImageResource(R.drawable.baseline_pause_24)
            }
        }
    }

    override fun onBackPressed() {
         mediaPlayer.pause()
        val inte=Intent(this,MainActivity::class.java)
         backintersitial.showAds(this,inte)
    }

    private fun nativeads() {
        MobileAds.initialize(this)


        val adLoader =
            AdLoader.Builder(this, getString(R.string.native_id))
                .forNativeAd { nativeAd ->
//                    binding?.loader?.visibility = View.GONE
                    binding?.myTemplate?.visibility = View.VISIBLE

                    val styles =
                        NativeTemplateStyle.Builder().build()
                    val template = findViewById<TemplateView>(R.id.my_template)
                    template.setStyles(styles)
                    template.setNativeAd(nativeAd)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("CHAGAN", adError.toString())
                    }
                })
                .build()

        adLoader.loadAd(AdRequest.Builder().build())


    }

    fun getspeciallottery() {
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("speciallottery")

        myRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                val data = dataSnapshot.getValue(Speciallottery::class.java)
                var name = dataSnapshot.child("lotteryname").value as String
                var url = dataSnapshot.child("result").value as String
                val value = dataSnapshot.child("visible").getValue(Boolean::class.java)
                name = data?.lotteryname.toString()
                url = data?.result.toString()
                binding.lotteryname.setText(Speciallottery.lotteryname)
                if (value == true) {
                    binding.speciallottery.visibility = View.VISIBLE
                } else {
                    binding.speciallottery.visibility = View.GONE
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                d("CHAGAN", "Special lottery Firebase $error")
            }
        })

    }

    override fun onResume() {
        super.onResume()
        intertitial.load(this)

    }

}