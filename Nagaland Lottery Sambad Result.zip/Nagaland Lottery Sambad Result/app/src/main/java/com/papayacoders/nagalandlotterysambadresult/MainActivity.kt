package com.papayacoders.nagalandlotterysambadresult

import android.animation.AnimatorSet
import android.animation.LayoutTransition
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.transition.ChangeBounds
import android.transition.TransitionManager
import android.util.Log.d
import android.view.View
import android.view.animation.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.google.android.ads.nativetemplates.NativeTemplateStyle
import com.google.android.ads.nativetemplates.TemplateView
import com.google.android.gms.ads.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.papayacoders.nagalandlotterysambadresult.ads.backintersitial
import com.papayacoders.nagalandlotterysambadresult.ads.intertitial
import com.papayacoders.nagalandlotterysambadresult.ads.mainapp
import com.papayacoders.nagalandlotterysambadresult.config.Result
import com.papayacoders.nagalandlotterysambadresult.databinding.ActivityMainBinding


class MainActivity : mainapp() {
    lateinit var binding: ActivityMainBinding
    var count = 10
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this, R.color.mainappbar)
        }
        loadresult()
        nativeads()
        intertitial.load(this)




        repeatFunctionCall(count)






        binding.sendwhatsaap.setOnClickListener {
            val phoneNumber = getString(R.string.phone_number)
            val message = "hi..."
            val url = "https://api.whatsapp.com/send?phone=$phoneNumber&text=${Uri.encode(message)}"

            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }
        binding.showresult.setOnClickListener {
            val inte = Intent(this, ResultActivity::class.java)
            intertitial.showAds(this, inte)

        }
    }

    private fun nativeads() {
        MobileAds.initialize(this)


        val adLoader =
            AdLoader.Builder(this, getString(R.string.native_id))
                .forNativeAd { nativeAd ->
//                    binding?.loader?.visibility = View.GONE
                    binding?.myTemplate?.visibility = View.VISIBLE

                    val styles =
                        NativeTemplateStyle.Builder().build()
                    val template = findViewById<TemplateView>(R.id.my_template)
                    template.setStyles(styles)
                    template.setNativeAd(nativeAd)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        d("CHAGAN", adError.toString())
                    }
                })
                .build()

        adLoader.loadAd(AdRequest.Builder().build())


    }

    override fun onResume() {
        super.onResume()
        intertitial.load(this)
        backintersitial.load(this)

    }

    fun loadresult() {
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference("lotterytime")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val url = snapshot.getValue(Result::class.java)
                val result_1 = snapshot.child("time1result").value as String
                val result_2 = snapshot.child("time2result").value as String
                val result_3 = snapshot.child("time3result").value as String
                url?.result1 = result_1.toString()
                url?.result2 = result_2.toString()
                url?.result3 = result_3.toString()

            }

            override fun onCancelled(error: DatabaseError) {
                d("CHAGAN", "Firebase load error :  ${error}")
            }

        })
    }

    fun CardView.fadeInAnimation() {
        val fadeIn = ObjectAnimator.ofFloat(this, "alpha", 0f, 1f)
        fadeIn.duration = 1000 // in milliseconds
        fadeIn.interpolator = AccelerateDecelerateInterpolator()
        fadeIn.start()
    }

    fun trans() {
        val cardView = binding.showresult

        val animation = TranslateAnimation(0f, -30f, 0f, 0f)
        animation.duration = 1000
        animation.fillAfter = true
        animation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation?) {}
            override fun onAnimationEnd(animation: Animation?) {
                val reverseAnimation = TranslateAnimation(-30f, 0f, 0f, 0f)
                reverseAnimation.duration = 1000
                reverseAnimation.fillAfter = true
                cardView.startAnimation(reverseAnimation)
            }

            override fun onAnimationRepeat(animation: Animation?) {}
        })
        cardView.startAnimation(animation)
    }

//    fun transminus() {
//        val cardView = binding.showresult
//
//        val animation = ScaleAnimation( 0f, -30f, 0f, -30f)
//        animation.duration = 1000
//        animation.fillAfter = true
//        animation.setAnimationListener(object : Animation.AnimationListener {
//            override fun onAnimationStart(animation: Animation?) {}
//            override fun onAnimationEnd(animation: Animation?) {
//                val reverseAnimation = ScaleAnimation(30f, 0f, 0f, 0f)
//                reverseAnimation.duration = 1000
//                reverseAnimation.fillAfter = true
//                cardView.startAnimation(reverseAnimation)
//            }
//
//            override fun onAnimationRepeat(animation: Animation?) {}
//        })
//        cardView.startAnimation(animation)
//    }

    fun repeatFunctionCall(times: Int) {
        if (times > 0) {
//            trans()
            val cardVieww = binding.showresult
            val animation = AnimationUtils.loadAnimation(this, R.anim.cardview_anim)
            cardVieww.startAnimation(animation)
            val handlerr = Handler()
            handlerr.postDelayed({
//                min()
                                 repeatFunctionCall(count)
            }, 1000)

        }
    }

//    fun min() {
//        transminus()
//
//        val handler = Handler()
//        handler.postDelayed({
//            repeatFunctionCall(count)
//        }, 1000)
//        count++
//    }

    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Are you sure you want to exit?")

            .setPositiveButton("Yes") { dialog, which ->
                // Exit the app
                finishAffinity()
            }
            .setNegativeButton("No") { dialog, which ->
                dialog.dismiss()
            }
            .show()

    }

}