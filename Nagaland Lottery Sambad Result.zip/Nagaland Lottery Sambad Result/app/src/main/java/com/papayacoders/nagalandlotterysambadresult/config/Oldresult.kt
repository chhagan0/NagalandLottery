package com.papayacoders.nagalandlotterysambadresult.config

data class Oldresult (
    var date:String?="",
    var result1:String?="",
    var result2:String?="",
    var result3:String?="",
)

