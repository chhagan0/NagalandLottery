package com.papayacoders.nagalandlotterysambadresult.config

object Speciallottery {
    var result:String? =""
    var lotteryname:String? =""
}