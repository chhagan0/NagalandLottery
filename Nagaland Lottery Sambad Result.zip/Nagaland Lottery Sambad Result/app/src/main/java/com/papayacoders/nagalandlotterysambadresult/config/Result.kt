package com.papayacoders.nagalandlotterysambadresult.config

object Result {
var result1:String?=""
var result2:String?=""
var result3:String?=""
}