package com.papayacoders.nagalandlotterysambadresult.result

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Log.d
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.ads.nativetemplates.NativeTemplateStyle
import com.google.android.ads.nativetemplates.TemplateView
import com.google.android.gms.ads.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.papayacoders.nagalandlotterysambadresult.Adapter.MyAdapter
import com.papayacoders.nagalandlotterysambadresult.R
import com.papayacoders.nagalandlotterysambadresult.ResultActivity
import com.papayacoders.nagalandlotterysambadresult.ads.backintersitial
import com.papayacoders.nagalandlotterysambadresult.ads.mainapp
import com.papayacoders.nagalandlotterysambadresult.config.Oldresult
import com.papayacoders.nagalandlotterysambadresult.databinding.ActivityOldResultBinding

class OldResultActivity : mainapp() {
    lateinit var binding:ActivityOldResultBinding
    lateinit var recyclerView: RecyclerView
    lateinit var arrayList:ArrayList<Oldresult>
     var db=Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityOldResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        recyclerView=binding.recyclerView
         recyclerView.layoutManager=LinearLayoutManager(this)
        arrayList= arrayListOf()
        MobileAds.initialize(this)
        db= FirebaseFirestore.getInstance()
        nativeads()
        binding.btnback.setOnClickListener {
            val inte= Intent(this, ResultActivity::class.java)
             backintersitial.showAds(this,inte)
        }
        db.collection("10").get().addOnSuccessListener {
            d("CHAGANN", "db Success: ${it.documents}")

                for (data in it.documents){
                    var result: Oldresult? =data.toObject(Oldresult::class.java)
                    if (result != null) {
                        arrayList.add(result)

                }
                recyclerView.adapter=MyAdapter(arrayList)
            }
        }
            .addOnFailureListener {
d("CHAGANN", "db Failed: $it")
            }

    }

    private fun nativeads() {
        MobileAds.initialize(this)


        val adLoader =
            AdLoader.Builder(this, getString(R.string.native_id2))
                .forNativeAd { nativeAd ->
//                    binding?.loader?.visibility = View.GONE
                    binding?.myTemplate?.visibility = View.VISIBLE

                    val styles =
                        NativeTemplateStyle.Builder().build()
                    val template = findViewById<TemplateView>(R.id.my_template)
                    template.setStyles(styles)
                    template.setNativeAd(nativeAd)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("CHAGAN", adError.toString())
                    }
                })
                .build()

        adLoader.loadAd(AdRequest.Builder().build())


    }

    override fun onBackPressed() {
        val inte=Intent(this,ResultActivity::class.java)
         backintersitial.showAds(this,inte)
    }

    override fun onResume() {
        super.onResume()
        MobileAds.initialize(this)

    }
}